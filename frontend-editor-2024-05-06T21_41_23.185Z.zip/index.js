

let bernado = [
'girafa',
'zebra',
 28, 
 'alfabeto', 
{
name: "Luan",
age: 26, 
isAdm: true
},
 true
]

console.log(`A segunda linha do seu array é ${bernado[4].name}`)


